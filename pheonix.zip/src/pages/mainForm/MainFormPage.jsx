import React, { useState } from "react";
import { formSchema, formSteps, initialValues } from "./utilis/formUtilis";
import { Form, Formik } from "formik";
import {
  Box,
  Button,
  CircularProgress,
  Container,
  Grid2,
  Paper,
  Stack,
  Toolbar,
} from "@mui/material";
import Step1 from "./components/Step1";
import Step3 from "./components/Step3";
import Step2 from "./components/Step2";
import axios from "axios";

const MainFormPage = () => {
  const [activeStep, setActiveStep] = useState(0);

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };


  console.log('formSchema[activeStep] ==> ', activeStep);

  return (
    <Container  sx={{marginTop:'7rem', paddingBottom:'2rem'}}>

<Paper>
      <Formik
        enableReinitialize
        initialValues={initialValues}
        validationSchema={formSchema[activeStep]}
        onSubmit={async (values, { setErrors }) => {
          try {
            const response = await axios.post('https://leads-om172-client.phonexa.com/lead/', values);
            console.log('Response:', response.data);
          } catch (error) {
            console.error('Error:', error);
          }

        }}
      >
        {({ setTouched, values, validateForm, isSubmitting, errors }) => (
          <Form sx={{width:'100%'}}>
            {console.log('errors ==> ', errors)}
            <Grid2 spacing={2} container width="100%">

                {activeStep === 0 && <Step1 />}
                {activeStep === 1 && <Step2 />}
                {activeStep === 2 && <Step3 />}
                <Stack
                  direction="row"
                  width="100%"
                  justifyContent="start"
                  spacing={1}
                  className="mt-2"
                >
                  <Toolbar className="px-0 align-items-center">
                    <Button
                      variant="mutedColor"
                      size="small"
                      type="button"
                      disabled={activeStep === 0}
                      onClick={handleBack}
                      sx={{ mr: 1 }}
                    >
                      Back
                    </Button>
                    <Box sx={{ flex: "1 1 auto" }} />

                    {activeStep < formSteps.length - 1 ? (
                      <Button
                        onClick={async () => {
                          const response = await validateForm(values);

                          console.log('response ==> ', response, values)
                          if (Object?.keys(response)?.length > 0) {
                            setTouched(response);
                            return;
                          }

                          handleNext();
                        }}
                        variant="contained"
                      >
                        Next
                      </Button>
                    ) : (
                      <Button
                        variant="contained"
                        size="small"
                        type="submit"
                        disabled={isSubmitting}
                      >
                        {isSubmitting && <CircularProgress size={20} />}
                        Submit
                      </Button>
                    )}
                  </Toolbar>
                </Stack>
 
            </Grid2>
          </Form>
        )}
      </Formik>
      </Paper>
    </Container>
  );
};

export default MainFormPage;
