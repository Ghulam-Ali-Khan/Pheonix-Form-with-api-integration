export const loanAmountOptions = [
    { value: '100', label: '100' },
    { value: '200', label: '200' },
    { value: '300', label: '300' },
    { value: '400', label: '400' },
    { value: '500', label: '500' },
    { value: '600', label: '600' },
    { value: '700', label: '700' },
    { value: '800', label: '800' },
    { value: '900', label: '900' },
    { value: '1000', label: '1000' },
    { value: '2000', label: '2000' },
    { value: '3000', label: '3000' },
    { value: '4000', label: '4000' },
    { value: '5000', label: '5000' }
  ];


  export const residentialStatusOptions = [
    { value: 'Rent', label: 'Rent' },
    { value: 'Own', label: 'Own' }
  ];

  export const timeAtCurrentAddressOptions = [
    { value: '1 to 5', label: '1 to 5' },
    { value: '5+', label: '5+' }
  ]

  export const employeementStatusOptions = [
    { value: 'Employed', label: 'Employed' },
    { value: 'Self employed', label: 'Self employed' }
  ]

  export const timeAtCurrentEmployerOptions = [
    { value: '1 to 5', label: '1 to 5' },
    { value: '5+', label: '5+' }
  ]

  export const timeAtBankOptions = [
    { value: '1 to 5', label: '1 to 5' },
    { value: '5+', label: '5+' }
  ]

 export const payFrequencyOptions = [
    { label: "Weekly", value: "Weekly" },
    { label: "Bi-weekly", value: "Bi-weekly" },
    { label: "Semi-monthly", value: "Semi-monthly" },
    { label: "Monthly", value: "Monthly" }
  ];

  export const activeMilitaryOptions = [
    { value: 'Yes', label: 'Yes' },
    { value: 'No', label: 'No' }
  ];

  export const accountTypeOptions = [
    { value: 'Checking', label: 'Checking' },
  ]