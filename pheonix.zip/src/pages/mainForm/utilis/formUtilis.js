import * as Yup from "yup";

const step1initialValues = {
  loanAmount: null,
  firstName: "",
  lastName: "",
  dob: "",
  email: "",
  homePhone: "",
  address: "",
  zip: "",
  city: "",
  state: "",
  ownHome: "",
  addressLengthMonths: "",
};

const step2initialValues = {
  incomeType: "",
  incomeNetMonthly: "",
  workCompanyName: "",
  workTimeAtEmployer: "",
  workPhone: "",
  incomePaymentFrequency: "",
  incomeNextDate1: "",
  incomeNextDate2: "",
  activeMilitary: "",
  ssn: "",
  driversLicenseNumber: "",
  driversLicenseState: "",
};

const step3initialValues = {
  bankName: "",
  routingNumber: "", //
  bankAccountNumber: "",
  bankAccountType: "",
  bankDirectDeposit: "",
  bankAccountLengthMonths: "",
  termsAndConditions: false,
};

export const initialValues = {
  ...step1initialValues,
 ...step2initialValues,
  ...step3initialValues,
};

const step1Validation = Yup.object({
  loanAmount: Yup.string().required("Required"),
  firstName: Yup.string().required("Required"),
  lastName: Yup.string().required("Required"),
  dob: Yup.string().required("Required"),
  email: Yup.string().required("Required"),
  homePhone: Yup.string().required("Required"),
  address: Yup.string().required("Required"),
  zip: Yup.string().required("Required"),
});

const step2Validation = Yup.object({
  incomeType: Yup.string().required("Required"),
  incomeNetMonthly: Yup.string().required("Required"),
  workCompanyName: Yup.string().required("Required"),
  workPhone: Yup.string().required("Required"),
  incomePaymentFrequency: Yup.string().required("Required"),
  incomeNextDate1: Yup.string().required("Required"),
  incomeNextDate2: Yup.string().required("Required"),
  activeMilitary: Yup.string().required("Required"),
  ssn: Yup.string().required("Required"),
  driversLicenseNumber: Yup.string().required("Required"),
});

const step3Validation = Yup.object({
  bankAccountNumber: Yup.string().required("Required"),
  bankDirectDeposit: Yup.string().required("Required"),
  bankAccountType: Yup.string().required("Required"),
});

export const formSchema = [step1Validation, step2Validation, step3Validation];

export const formSteps = ['Step 1', 'Step 2', 'Step 3'];